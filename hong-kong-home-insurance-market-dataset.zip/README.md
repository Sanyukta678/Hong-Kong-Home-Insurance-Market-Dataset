# Hong Kong Home Insurance Market — Dataset

This dataset contains structured metadata and derived summaries from the public landing page of the Hong Kong Home Insurance Market report (BF3568) by Next Move Strategy Consulting.

It does **not** include any paid PDF content — only publicly accessible information reorganized into research‑friendly files.
